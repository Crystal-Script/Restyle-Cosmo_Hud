
local beltStatus = false
local hunger, thirst, stress = 0, 0, 0
local posX, posY, width, height = -0.015, -0.015, 0.16, 0.25

Citizen.CreateThread(function()
    ESX = exports["es_extended"]:getSharedObject()
end)

-- Principal Event
AddEventHandler('esx_status:onTick', function(data)
	local playerPed = PlayerPedId()
    
	for k, v in pairs(data) do
		if v.name == 'hunger' then
			hunger = v.percent
		elseif v.name == 'thirst' then
			thirst = v.percent
		elseif v.name == 'stress' then
			stress = v.percent
		end
	end
	
	if hunger == 0 or thirst == 0 then
        ForcePedMotionState(playerPed, 1110276645, 0, 0, 0)
    end
end)

-- Principal Loop
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(shared.ticktime)
        local pedID = PlayerPedId()
        local pHealth = (GetEntityHealth(pedID) - 100)
        local pArmour = GetPedArmour(pedID)

        -- Player ID
        if shared.serverid then
            SendNUIMessage({
                pid = true,
                playerid = GetPlayerServerId(PlayerId()),
            })
        else
            SendNUIMessage({pid = false})
        end

        -- Ped oxygen underwater
        if IsPedSwimmingUnderWater(pedID) then
            SendNUIMessage({showOxygen = true})
        else
            SendNUIMessage({showOxygen = false})
        end

        -- Entity health
        if shared.showhealth then
            SendNUIMessage({health = true})
        else
            if (pHealth >= 100) then
                SendNUIMessage({health = false})
            else
                SendNUIMessage({health = true})
            end
        end

        -- Ped stamina while sprinting
        if shared.showstamina then
            SendNUIMessage({showStamina = true})
        else
            SendNUIMessage({showStamina = false})
        end
		
        -- Stress config
        if shared.showstress then
            if stress > 1 then
                SendNUIMessage({showStress = true})
            else
                SendNUIMessage({showStress = false})
            end
        else
            SendNUIMessage({showStress = false})
        end
        
        -- Belt config
        if shared.seatbelt then
            SendNUIMessage({showBelt = true})
        else
            SendNUIMessage({showBelt = false})
        end
        
        -- HUD visibility checks
        if IsPauseMenuActive() or IsPlayerSwitchInProgress() or (shared.gprendering and not IsGameplayCamRendering()) then
            SendNUIMessage({showUi = false})
        elseif not IsPauseMenuActive() then
            SendNUIMessage({showUi = true})
        end

        -- SpeedO Config
        if IsPedInAnyVehicle(pedID, false) and not IsPedInFlyingVehicle(pedID) and not IsPedInAnySub(pedID) then
            SetRadarZoom(1100)
            SendNUIMessage({showSpeedo = true})
        elseif not IsPedInAnyVehicle(pedID, false) then
            SendNUIMessage({showSpeedo = false})
        end

        -- Fuel config
        if shared.showfuel then
            SendNUIMessage({showFuel = true})

            if IsPedInAnyVehicle(pedID, true) then
                local veh = GetVehiclePedIsUsing(pedID, false)
                local fuellevel = GetVehicleFuelLevel(veh)
                SendNUIMessage({
                    action = "update_fuel",
                    fuel = fuellevel
                })
            end
        else
            SendNUIMessage({showFuel = false})
        end

        -- Check if player is in radio
        if LocalPlayer.state['radioChannel'] ~= nil then
            if LocalPlayer.state['radioChannel'] > 0 and LocalPlayer.state['radioChannel'] ~= 0 then
                SendNUIMessage({inRadio = true})
            elseif LocalPlayer.state['radioChannel'] == 0 then
                SendNUIMessage({inRadio = false})
            end
        end

        -- Radar config
        if not shared.showradar then
            if IsPedInAnyVehicle(pedID, false) then
                DisplayRadar(true)
                SendNUIMessage({showOutlines = true})
                while IsPedInAnyVehicle(pedID, false) do
                    Citizen.Wait(0)
                    ScaleformMovieMethodAddParamInt(3)
                    EndScaleformMovieMethod()
                    SetBlipAlpha(GetNorthRadarBlip(), 0)
                    HideHudComponentThisFrame(6)
                    HideHudComponentThisFrame(7)
                    HideHudComponentThisFrame(8)
                    HideHudComponentThisFrame(9)
                end
            else
                DisplayRadar(false)
                SendNUIMessage({showOutlines = false})
            end
        else
            DisplayRadar(true)
            SendNUIMessage({showOutlines = true})
        end

        -- Stress config
        if shared.showstress then
            if math.floor(stress) >= shared.minstresseffect then
                Citizen.Wait(10000)
                forRepeat()
            elseif math.floor(stress) == 100 then
                Citizen.Wait(500)
                forRepeat()
            end
        end
		
        -- Information sent to JavaScript
        SendNUIMessage({
            action = "update_hud",
            hp = pHealth,
            armor = pArmour,
            hunger = hunger,
            thirst = thirst,
            stress = stress,
            isBeltOn = beltStatus,
            stamina = GetPlayerSprintTimeRemaining(PlayerId()) * 10,
            oxygen = GetPlayerUnderwaterTimeRemaining(PlayerId()) * 10,
            talking = NetworkIsPlayerTalking(PlayerId())
        })
    end
end)

-- SpeedO configs
Citizen.CreateThread(function()
	while true do
        Citizen.Wait(100)
		local pedID = PlayerPedId()
		
		-- Vehicle config while entity inside
		if IsPedInAnyVehicle(pedID, true) then
			local veh = GetVehiclePedIsUsing(pedID, false)
			local speed = math.floor(GetEntitySpeed(veh) * 3.6)
			
			SendNUIMessage({
				speed = speed
			})
		end
	end
end)



-- Microphone
AddEventHandler('pma-voice:setTalkingMode', function(newTalkingRange)
    SendNUIMessage({
        action = "voice_level", 
        voicelevel = newTalkingRange
    })
end)

-- Seatbelt events
RegisterNetEvent("cosmo_hud:isSeatbeltOn")
AddEventHandler("cosmo_hud:isSeatbeltOn", function(isOn)
    beltStatus = isOn
    SendNUIMessage({
        isBeltOn = beltStatus
    })
end)

if shared.showstress then
    -- Stress function that makes you close your eyes when stress is too high
    function forRepeat()
        Citizen.Wait(750)
        DoScreenFadeOut(200)
        Citizen.Wait(shared.ticktime)
        DoScreenFadeIn(200)
    end

    -- Updated stress from server
    RegisterNetEvent('cosmo_hud:UpdateStress')
    AddEventHandler('cosmo_hud:UpdateStress', function(newStress)
        stress = newStress
    end)
end


RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded',function()
    SetRadarZoom(1200)
end)

RegisterNetEvent('esx:onPlayerSpawn')
AddEventHandler('esx:onPlayerSpawn', function()
    SetRadarZoom(1200)
end)

CreateThread(function()
    Wait(50)
    local aspettoPredefinito = 1920 / 1080 
    local risoluzioneX, risoluzioneY = GetActiveScreenResolution()
    local proporzioni = risoluzioneX / risoluzioneY
    local minimappa = 0
    if proporzioni > aspettoPredefinito then
        minimappa = ((aspettoPredefinito - proporzioni) / 3.6) - 0.008
    end
    RequestStreamedTextureDict("squaremap", false)
    while not HasStreamedTextureDictLoaded("squaremap") do
        Wait(150)
    end
    SetMinimapClipType(0)
    AddReplaceTexture("platform:/textures/graphics", "radarmasksm", "squaremap", "radarmasksm")
    AddReplaceTexture("platform:/textures/graphics", "radarmask1g", "squaremap", "radarmasksm")

    SetMinimapComponentPosition("minimap", "L", "B", 0.0 + minimappa, -0.047, 0.1538, 0.183)
    SetMinimapComponentPosition("minimap_mask", "L", "B", 0.0 + minimappa, 0.0, 0.128, 0.20)
    SetMinimapComponentPosition('minimap_blur', 'L', 'B', -0.01 + minimappa, 0.035, 0.262, 0.310)       
    SetBlipAlpha(GetNorthRadarBlip(), 0)
    SetRadarBigmapEnabled(true, false)
    SetMinimapClipType(0)
    Wait(50)
    SetRadarBigmapEnabled(false, false)
    Wait(1200)
end)
